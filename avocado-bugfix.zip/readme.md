
In Chrome 45 the Slimming Paint feature is enabled by default. This feature caused rendering issues with the Wordpress Admin menu. This extension works around the issue by injecting one line of CSS into the Wordpress admin pages that corrects the display issue.

More information on the bug can be found in the related Wordpress and Chrome tickets.

* https://core.trac.wordpress.org/ticket/33199
* https://code.google.com/p/chromium/issues/detail?id=509179
